from dashare.util.info_tool import create_dashare_metadb

create_dashare_metadb()